Start-Process -FilePath "$env:temp/boom/mpg123.exe" -WindowStyle Hidden -ArgumentList "--loop -1 $env:temp/boom/boom.mp3"
while ($true) {
  Start-Process -FilePath "$env:temp/boom/nircmd.exe" -WindowStyle Hidden -ArgumentList "mutesysvolume 0"
  Start-Process -FilePath "$env:temp/boom/nircmd.exe" -WindowStyle Hidden -ArgumentList "setsysvolume 65535"
  Start-Sleep -Seconds 0.5
}